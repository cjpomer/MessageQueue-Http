﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace Anon.MessageQueueServer.ServiceBus
{
    public static class WebHostBuilderExt
    {
        public static IWebHostBuilder UseServiceBusServer(this IWebHostBuilder builder, Action<ServiceBusServerOptions> options)
        {
            return builder.ConfigureServices(services =>
            {
                services.Configure(options)
                    .AddSingleton<IServer, ServiceBusServer>();
            });
        }
    }
}
