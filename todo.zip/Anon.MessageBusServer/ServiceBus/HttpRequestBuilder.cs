﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Anon.MessageQueueServer.ServiceBus
{
    public class HttpRequestBuilder
    {
        byte[] body = new byte[] { };
        List<(string, string)> headerBuilder = new List<(string, string)>();
        string host;
        string method;
        string path;
        List<(string, string)> queryBuilder = new List<(string, string)>();

        public HttpRequestBuilder AddHeader(string key, string value)
        {
            headerBuilder.Add((key, value));
            return this;
        }

        public HttpRequestBuilder AddQuery(string lhs, string rhs)
        {
            queryBuilder.Add((lhs, rhs));
            return this;
        }

        public HttpRequest Build()
        {
            if (string.IsNullOrEmpty(host)) { throw new InvalidOperationException("'Host' is a required field"); }

            return new HttpRequest
            {
                Body = body,
                Headers = headerBuilder.ToArray(),
                Host = host,
                Method = method,
                Path = path,
                Query = "?" + queryBuilder.Select(cur => $"{cur.Item1}={cur.Item2}").Aggregate((cur, agg) => $"{agg}&{cur}"),
            };
        }

        public HttpRequestBuilder SetBody(byte[] body)
        {
            this.body = body;
            return this;
        }

        public HttpRequestBuilder SetHost(string host)
        {
            this.host = host;
            return this;
        }

        public HttpRequestBuilder SetMethod(string method)
        {
            this.method = method;
            return this;
        }

        public HttpRequestBuilder SetPath(string path)
        {
            this.path = path;
            return this;
        }

    }
}

/*
    QueryString QueryString { get; set; }
    Stream Body { get; set; }
    string ContentType { get; set; }
    long? ContentLength { get; set; }
    IHeaderDictionary Headers { get; }
    string Protocol { get; set; }
    IQueryCollection Query { get; set; }
    PathString Path { get; set; }
    PathString PathBase { get; set; }
    HostString Host { get; set; }
    string Scheme { get; set; }
    string Method { get; set; }
*/