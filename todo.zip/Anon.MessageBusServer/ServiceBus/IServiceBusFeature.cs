﻿using Microsoft.Azure.ServiceBus;

namespace Anon.MessageQueueServer.ServiceBus
{
    public interface IServiceBusFeature
    {
        Message Message { get; set; }
    }
}