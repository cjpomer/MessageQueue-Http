﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting.Internal;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Hosting.Server.Features;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.Azure.ServiceBus;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace Anon.MessageQueueServer.ServiceBus
{
    public class ServiceBusServer : IServer
    {
        private readonly ServiceBusServerOptions options;
        private readonly IQueueClient client;
        private readonly IServiceScopeFactory serviceScopeFactory;

        public IFeatureCollection Features { get; private set; } = new FeatureCollection();

        public ServiceBusServer(IOptions<ServiceBusServerOptions> options, IQueueClient client, IServiceScopeFactory serviceScopeFactory)
        {
            this.options = options.Value;
            this.client = client;
            this.serviceScopeFactory = serviceScopeFactory;

            Features.Set<IHttpRequestFeature>(new HttpRequestFeature());
            Features.Set<IHttpResponseFeature>(new HttpResponseFeature());
        }

        public void Dispose()
        {
        }

        public Task StartAsync<TContext>(IHttpApplication<TContext> application, CancellationToken cancellationToken)
        {
            Func<IFeatureCollection> funcFeatures = () =>
            {
                var features = new FeatureCollection();
                features.Set<IHttpRequestFeature>(new HttpRequestFeature());
                features.Set<IHttpResponseFeature>(new HttpResponseFeature());
                return features;
            };

            if (application is IHttpApplication<HostingApplication.Context>)
            {
                var serviceBusProcessor = new ServiceBusProtocolTransition((IHttpApplication<HostingApplication.Context>)application, funcFeatures);
                client.RegisterMessageHandler(serviceBusProcessor.ProcessMessagesAsync,
                    new MessageHandlerOptions(serviceBusProcessor.ExceptionReceivedHandler)
                    {
                        MaxConcurrentCalls = options.MaxConcurrentCalls,
                        AutoComplete = options.AutoComplete,
                    });

                return Task.CompletedTask;
            }
            else
            {
                throw new InvalidOperationException();
            }
        }

        public async Task StopAsync(CancellationToken cancellationToken)
        {
            await client.CloseAsync().ConfigureAwait(false);
        }
    }
}
