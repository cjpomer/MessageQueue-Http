﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting.Internal;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Authentication;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.Azure.ServiceBus;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;

namespace Anon.MessageQueueServer.ServiceBus
{
    public class ServiceBusProtocolTransition
    {
        private readonly IHttpApplication<HostingApplication.Context> application;
        private readonly Func<IFeatureCollection> funcFeatures;

        public ServiceBusProtocolTransition(IHttpApplication<HostingApplication.Context> application, Func<IFeatureCollection> funcFeatures)
        {
            this.funcFeatures = funcFeatures ?? throw new ArgumentNullException(nameof(funcFeatures));
            this.application = application ?? throw new ArgumentNullException(nameof(application));
        }

        public async Task ExceptionReceivedHandler(ExceptionReceivedEventArgs arg)
        {
            throw new NotImplementedException();
        }

        public async Task ProcessMessagesAsync(Message message, CancellationToken token)
        {
            Exception applicationException = null;
            var context = application.CreateContext(funcFeatures());
            try
            {
                Prepare(message, context);
                await application.ProcessRequestAsync(context);
            }
            catch (JsonSerializationException ex)
            {
                applicationException = ex;
            }
            catch (Exception ex)
            {
                applicationException = ex;
            }

            application.DisposeContext(context, applicationException);

        }

        private void Prepare(Message message, HostingApplication.Context context)
        {
            context.HttpContext.Features.Set<IServiceBusFeature>(new ServiceBusFeature() { Message = message });

            var messageBody = Encoding.UTF8.GetString(message.Body);
            var serviceBusRequest = JsonConvert.DeserializeObject<HttpRequest>(messageBody);

            var request = context.HttpContext.Request;
            var headers = serviceBusRequest.Headers.GroupBy(tuple => tuple.Item1).Select(group => (group.Key, Values: new StringValues(group.Select(g => g.Item2).ToArray())));
            foreach (var kvp in headers)
            {
                request.Headers.Add(kvp.Key, kvp.Values);
            }
            request.QueryString = new QueryString(serviceBusRequest.Query);
            request.Body = new MemoryStream(serviceBusRequest.Body);
            request.Path = serviceBusRequest.Path;
            request.Host = new HostString(serviceBusRequest.Host);
            request.Method = serviceBusRequest.Method;
        }
    }
}
