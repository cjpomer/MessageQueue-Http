﻿namespace Anon.MessageQueueServer.ServiceBus
{
    public struct HttpRequest
    {
        public byte[] Body { get; set; }
        public (string, string)[] Headers { get; set; }
        public string Host { get; set; }
        public string Method { get; set; }
        public string Path { get; set; }
        public string Query { get; set; }
    }
}

/*
    QueryString QueryString { get; set; }
    Stream Body { get; set; }
    string ContentType { get; set; }
    long? ContentLength { get; set; }
    IHeaderDictionary Headers { get; }
    string Protocol { get; set; }
    IQueryCollection Query { get; set; }
    PathString Path { get; set; }
    PathString PathBase { get; set; }
    HostString Host { get; set; }
    string Scheme { get; set; }
    string Method { get; set; }
*/