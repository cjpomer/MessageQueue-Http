﻿using Microsoft.Azure.ServiceBus;

namespace Anon.MessageQueueServer.ServiceBus
{
    public class ServiceBusFeature : IServiceBusFeature
    {
        public Message Message { get; set; }
    }
}