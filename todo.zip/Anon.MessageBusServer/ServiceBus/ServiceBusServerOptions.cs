﻿namespace Anon.MessageQueueServer.ServiceBus
{
    public class ServiceBusServerOptions
    {
        public int MaxConcurrentCalls { get; set; } = 1;
        public bool AutoComplete { get; set; } = false;
    }
}
