﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Anon.MessageQueueServer.ServiceBus;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.ServiceBus;
using Microsoft.Extensions.DependencyInjection;
using Anon.Measures.AspNetCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Anon.MessageQueueServer
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSingleton<IQueueClient, TestQueueClient>()
                .AddLogging(builder => builder.AddFilter("Microsoft", LogLevel.Warning))
                .AddMeasures("Test", "0.0.0.1")
                .AddMvc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.UseMeasures();
            app.UseMvc(mvc =>
                mvc.MapRoute("test", "{controller=Test}/{action=Index}/{id?}")
            );
        }
    }
}
