﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using Anon.MessageQueueServer.ServiceBus;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Anon.MessageQueueServer
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateWebHostBuilder(args).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseServiceBusServer(options =>
                {
                    options.AutoComplete = false;
                    options.MaxConcurrentCalls = 1;
                })
                .UseStartup<Startup>();
    }
}
