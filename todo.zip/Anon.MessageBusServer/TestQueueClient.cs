﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Anon.MessageQueueServer.ServiceBus;
using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Core;
using Newtonsoft.Json;

namespace Anon.MessageQueueServer
{
    internal class TestQueueClient : IQueueClient
    {
        private readonly CancellationTokenSource source = new CancellationTokenSource();

        private Func<Message, CancellationToken, Task> handler;
        private Func<ExceptionReceivedEventArgs, Task> exceptionHandler;

        public string QueueName => throw new NotImplementedException();

        public int PrefetchCount { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public ReceiveMode ReceiveMode => throw new NotImplementedException();

        public string ClientId => throw new NotImplementedException();

        public bool IsClosedOrClosing => throw new NotImplementedException();

        public string Path => throw new NotImplementedException();

        public TimeSpan OperationTimeout { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public ServiceBusConnection ServiceBusConnection => throw new NotImplementedException();

        public IList<ServiceBusPlugin> RegisteredPlugins => throw new NotImplementedException();

        public TestQueueClient()
        {
            Task.Run(async () =>
            {
                Message message;
                int i = 1;
                do
                {
                    await Task.Delay(1000, source.Token);

                    Func<Message, CancellationToken, Task> h;
                    lock (this)
                    {
                        h = this.handler;
                    }
                    if (h != null)
                    {
                        var request = new HttpRequestBuilder()
                            .AddHeader("host", "localhost:4242")
                            .AddQuery("test", "true")
                            .SetHost("http://example.com")
                            .SetMethod("get")
                            .SetPath("/test")
                            .Build();
                        message = new Message(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(request)));
                        await h(message, CancellationToken.None);
                    }
                }
                while (true);
            }, source.Token);
        }


        public Task AbandonAsync(string lockToken, IDictionary<string, object> propertiesToModify = null)
        {
            throw new NotImplementedException();
        }

        public Task CancelScheduledMessageAsync(long sequenceNumber)
        {
            throw new NotImplementedException();
        }

        public Task CloseAsync()
        {
            lock (this)
            {
                this.handler = null;
                this.exceptionHandler = null;
            }
            source.Cancel();
            return Task.CompletedTask;
        }

        public Task CompleteAsync(string lockToken)
        {
            throw new NotImplementedException();
        }

        public Task DeadLetterAsync(string lockToken, IDictionary<string, object> propertiesToModify = null)
        {
            throw new NotImplementedException();
        }

        public Task DeadLetterAsync(string lockToken, string deadLetterReason, string deadLetterErrorDescription = null)
        {
            throw new NotImplementedException();
        }

        public void RegisterMessageHandler(Func<Message, CancellationToken, Task> handler, Func<ExceptionReceivedEventArgs, Task> exceptionReceivedHandler)
        {
            lock (this)
            {
                this.handler = handler;
                this.exceptionHandler = exceptionReceivedHandler;
            }
        }

        public void RegisterMessageHandler(Func<Message, CancellationToken, Task> handler, MessageHandlerOptions messageHandlerOptions)
        {
            lock (this)
            {
                this.handler = handler;
            }
        }

        public void RegisterPlugin(ServiceBusPlugin serviceBusPlugin)
        {
            throw new NotImplementedException();
        }

        public void RegisterSessionHandler(Func<IMessageSession, Message, CancellationToken, Task> handler, Func<ExceptionReceivedEventArgs, Task> exceptionReceivedHandler)
        {
            throw new NotImplementedException();
        }

        public void RegisterSessionHandler(Func<IMessageSession, Message, CancellationToken, Task> handler, SessionHandlerOptions sessionHandlerOptions)
        {
            throw new NotImplementedException();
        }

        public Task<long> ScheduleMessageAsync(Message message, DateTimeOffset scheduleEnqueueTimeUtc)
        {
            throw new NotImplementedException();
        }

        public Task SendAsync(Message message)
        {
            throw new NotImplementedException();
        }

        public Task SendAsync(IList<Message> messageList)
        {
            throw new NotImplementedException();
        }

        public void UnregisterPlugin(string serviceBusPluginName)
        {
            throw new NotImplementedException();
        }
    }
}